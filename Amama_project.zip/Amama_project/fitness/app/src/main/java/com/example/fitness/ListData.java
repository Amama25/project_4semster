package com.example.fitness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ListData extends AppCompatActivity {
    TextView data_name;
    ImageView data_image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_data);

        data_image = findViewById(R.id.list_image);
        data_name = findViewById(R.id.list_data);

        Intent intent = getIntent();

        data_name.setText(intent.getStringExtra("data_name"));
        data_image.setImageResource(intent.getIntExtra("data_image",0));


    }
}