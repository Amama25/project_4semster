package com.example.fitness;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListView extends AppCompatActivity {

    View list;
    String[] h_names = {"Heart","Food","Diabetic","Mental","Lifestyle"};
    int[] h_images = {R.drawable.heart,R.drawable.food,R.drawable.diabetic,R.drawable.mental,R.drawable.lifestyle};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        list = findViewById(R.id.list_view);
        CustomAdapter customAdapter = new CustomAdapter();


    }

    private class CustomAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return h_images.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.row_data,null);

            TextView names = view.findViewById(R.id.list_data);
            ImageView images = view.findViewById(R.id.list_image);
            return view;

        }
    }
}