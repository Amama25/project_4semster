package com.example.fitness;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UserProfile extends AppCompatActivity {

    TextInputLayout fullNameLable,emailLable,ageLable,heightLable,weightLable;
    String _FullName,_Email,_Age,_Height,_Weight;

    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        reference = FirebaseDatabase.getInstance().getReference("users");

        fullNameLable = findViewById(R.id.fullname_feild);
        emailLable = findViewById(R.id.email_profile);
        ageLable = findViewById(R.id.age);
        heightLable = findViewById(R.id.height);
        weightLable = findViewById(R.id.weight);

        showAllData();
    }

    private void showAllData() {
        Intent intent = getIntent();
        _FullName = intent.getStringExtra("fullname");
        _Email = intent.getStringExtra("email");
        _Age = intent.getStringExtra("age");
        _Height = intent.getStringExtra("height");
        _Weight = intent.getStringExtra("weight");

        fullNameLable.getEditText().setText(_FullName);
        emailLable.getEditText().setText(_Email);
        ageLable.getEditText().setText(_Age);
        heightLable.getEditText().setText(_Height);
        weightLable.getEditText().setText(_Weight);

    }

    public void update(){
        if (isNameChanged() ){
            Toast.makeText(this, "Data has been updated", Toast.LENGTH_LONG).show();
        }
        else Toast.makeText(this, "Data is same and can not updated", Toast.LENGTH_LONG).show();
    }

    private boolean isNameChanged() {
        if (!_FullName.equals(fullNameLable.getEditText().getText().toString())){
            reference.child(_FullName).child("name").setValue((fullNameLable.getEditText().getText().toString()));
            _FullName = fullNameLable.getEditText().getText().toString();
        return true;
        }
        else {
            return false;
        }
    }
}

